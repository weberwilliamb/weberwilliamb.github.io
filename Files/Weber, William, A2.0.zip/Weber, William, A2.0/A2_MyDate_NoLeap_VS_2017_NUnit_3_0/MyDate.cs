﻿//William B Weber
//BIT 142 - Fall - 2018
//A2.0
using System;

namespace MyDate_StudentWork
{
    class MyDate // NOT WORKING
    {
        private int tDay;
        private int tMonth;

        public MyDate()  //default constructor.  default variables to 1.
        {
            tMonth = 1;
            tDay = 1;
        }

        public MyDate(int month, int day)  //instance constructor
        {
            if (month >= 1 && month <= 12) //check to see if input is valid month 1-12
                tMonth = month;
            else
                tMonth = 1; //if not, set month to 1
            //first condition checks if the input month has 31 days AND days are within 1-31
            //second condition checks for 30 days AND days are within 1-30
            //third condition checks for 28 days AND days are within 1-28
            //else all conditions fail, then day is set to 1
            if ((tMonth == 1 || tMonth == 3 || tMonth == 5 || tMonth == 7 || tMonth == 8 || tMonth == 10 || tMonth == 12) && (day >= 1 && day <= 31))
                tDay = day;
            else if ((tMonth == 4 || tMonth == 6 || tMonth == 9 || tMonth == 11) && (day >= 1 && day <= 30))
                tDay = day;
            else if ((tMonth == 2) && (day >= 1 && day <= 28))
                tDay = day;
            else
                tDay = 1;
        }

        public MyDate(MyDate other) //copy constructor
        {                           //initialize instance variables
            tMonth = other.tMonth;
            tDay = other.tDay;
        }

        public int getDay()
        {
            return tDay;
        }

        public int getMonth()
        {
            return tMonth;
        }

        public void setDate(int month, int day) //two parameter constructor
        {
            if (month >= 1 && month <= 12) //checks is given month is valid, else set to month to 1
                tMonth = month;
            else
                tMonth = 1;
            //first condition checks if the input month has 31 days AND days are within 1-31
            //second condition checks for 30 days AND days are within 1-30
            //third condition checks for 28 days AND days are within 1-28
            //else all conditions fail, then day is set to 1
            if ((tMonth == 1 || tMonth == 3 || tMonth == 5 || tMonth == 7 || tMonth == 8 || tMonth == 10 || tMonth == 12) && (day >= 1 && day <= 31))
                tDay = day;
            else if ((tMonth == 4 || tMonth == 6 || tMonth == 9 || tMonth == 11) && (day >= 1 && day <= 30))
                tDay = day;
            else if ((tMonth == 2) && (day >= 1 && day <= 28))
                tDay = day;
            else
                tDay = 1;
        }

        public string toString() //concatenate strings to print month/day as 10/11.
        {
            string s1 = Convert.ToString(tMonth);
            string s2 = "/";
            string s3 = Convert.ToString(tDay);
            string s4 = s1 + s2 + s3;
            return s4;
        }

        public bool Equals(MyDate d) //check if today is the same as bday
        {
            if ((tMonth == d.tMonth) && (tDay == d.tDay)) //compare the two months AND the days, return true if the same
                return true;

            if (!((tMonth == d.tMonth) && (tDay == d.tDay))) //compare the two months AND the days, return false if not the same
                return false;
            return false;

        }

        public int daysInMonth()  //checks the month given (tMonth) as sets the amount of days for that month.
        {
            switch (tMonth)
            {
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12:
                    return 31;
                case 4:
                case 6:
                case 9:
                case 11:
                    return 30;
                case 2:
                    return 28;
                default:
                    return -1;
            }
        }

        public void nextDay()
        {   //check month to see if it's a month with 31 days
            if (tMonth == 1 || tMonth == 3 || tMonth == 5 || tMonth == 7 || tMonth == 8 || tMonth == 10 || tMonth == 12)
            {
                if (tDay <= 31)
                {
                    tDay++; //if day is 31 or less, increment
                    {
                        if (tDay > 31) //if increment pushes day past 31, then increment month
                        {
                            tMonth++;
                            if(tMonth == 13)  //block of code that deals with Dec 31st.  13th month is reset as Jan 1st
                            {
                                tMonth = 1;
                            }
                            tDay = 1;
                        }
                    }
                }
            }
            //check month to see if it's a month with 30 days.
            //same logic as above, but without Dec 31st code.
            else if (tMonth == 4 || tMonth == 6 || tMonth == 9 || tMonth == 11)
            {
                if (tDay <= 30)
                {
                    tDay++;
                    if (tDay > 30)
                    {
                        tMonth++;
                        tDay = 1;
                    }
                }
            } 
            else if (tMonth == 2) //check to see if given month is Feb
            {
                if (tDay <= 28)
                {
                    tDay++;
                    if (tDay > 28)
                    {
                        tMonth++;
                        tDay = 1;
                    }
                }
            }
        }
    }

}
