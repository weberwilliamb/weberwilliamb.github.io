﻿using System;
using System.ComponentModel.DataAnnotations;
namespace IndyBooks.ViewModels
{
    public class SearchViewModel
    {
        //TODO: Add properties needed for searching

        [Key]
        public int Id { get; set; }

        [Required]
        public string Title { get; set; }

        [Required]
        public string Author { get; set; }

        public string Edition { get; set; }

        [Required]
        [DataType(DataType.Currency)]
        public decimal minPrice { get; set; }

        [Required]
        [DataType(DataType.Currency)]
        public decimal maxPrice { get; set; }

        [Display(Name = "Publication Year")]
        public string Year { get; set; }
    }
}
